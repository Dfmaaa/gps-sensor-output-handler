/**
 * Program to provide information on a GPS track stored in a file.
 *
 * @author Fariya Achhab
 */
public class TrackInfo {
  public static void main(String[] args) {
    //The only argument we expect is the file name of the CSV file.
    if(args.length!=1){
      System.out.println("Usage: java TrackInfo [csv filename]");
      System.exit(0);
    }
    try{
      //After we create the object, the code inside the constructor reads the file and stores Point objects from the file in a sequence.
      Track t=new Track(args[0]);
      //Printing information about the sequence of Point objects extracted from the CSV file.
      System.out.println(t.size() + " points in track");
      System.out.println("lowest point is " + t.lowestPoint().toString());
      System.out.println("Highest point is " + t.highestPoint().toString());
      System.out.println("Total distance = " + t.totalDistance()/1000 + " km"); //total distance is divided by 1000 for unit conversion ie. m to km.
      System.out.println("Average speed = " + t.averageSpeed() + " m/s");
    }
    catch(Exception e){
      //if something goes wrong, we print the error message, and exit with error code 1.
      e.printStackTrace();
      System.exit(1);
    }
  }
}
