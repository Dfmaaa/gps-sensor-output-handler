/**
 * Program to provide information on a GPS track stored in a file.
 *
 * @author Fariya Achhab
 */
public class TrackInfo {
  public static void main(String[] args) {
    if(args.length!=1){
      System.out.println("Usage: java TrackInfo [csv filename]");
      System.exit(0);
    }
    try{
      Track t=new Track(args[0]);
      System.out.println(t.size() + " points in track");
      System.out.println("lowest point is " + t.lowestPoint().toString());
      System.out.println("Highest point is " + t.highestPoint().toString());
      System.out.println("Total distance = " + t.totalDistance()/1000 + " km");
      System.out.println("Average speed = " + t.averageSpeed() + " m/s");
    }
    catch(Exception e){
      e.printStackTrace();
      System.exit(1);
    }
  }
}
