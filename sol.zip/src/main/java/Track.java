import java.io.IOException;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.time.temporal.ChronoUnit;
/**
 * Represents a point in space and time, recorded by a GPS sensor.
 *
 * @author Fariya Achhab
 */
public class Track {
  
  private ArrayList<Point> objects;
  public Track(String filename) throws IOException{
    objects=new ArrayList<Point>();
    readFile(filename);
  }
  public void readFile(String filename) throws IOException{
    File f=new File(filename);
    Scanner read=new Scanner(f);
    read.nextLine();
    while(read.hasNextLine()){
      String raw_line=read.nextLine();
      //Format is Time, Longitude, Latitude, Elevation
      String[] fields=raw_line.split(",");
      if(fields.length!=4){
        read.close();
        throw new GPSException("Incorrect number of fields.");
      }
      ZonedDateTime time=ZonedDateTime.parse(fields[0]);
      double longitude=Double.parseDouble(fields[1]);
      double latitude=Double.parseDouble(fields[2]);
      double elevation=Double.parseDouble(fields[3]);
      objects.add(new Point(time,longitude,latitude,elevation));
    }
    read.close();
   }

  public void add(Point p){
    objects.add(p);
  }
  public Point get(int index){
    if(index<0||index>size()){
      throw new GPSException("whoopsie u r wrong");
    }
    return objects.get(index);
  }

  public int size(){
    return objects.size();
  }

  public Point lowestPoint(){
    Point lowest=get(0);
    int sequence_length=size();
    for(int counter=1;counter<sequence_length;counter++){
      if(lowest.getElevation()>get(counter).getElevation()){
        lowest=get(counter);
      }
    }
    return lowest;
  }

  public Point highestPoint(){
    Point highest=get(0);
    int sequence_length=size();
    for(int counter=1;counter<sequence_length;counter++){
      if(highest.getElevation()<get(counter).getElevation()){
        highest=get(counter);
      }
    }
    return highest;
  }

  public double totalDistance(){
    double sum=0.0;
    int sequence_length=size();
    for(int counter=0;counter<sequence_length-1;counter++){
      sum+=Point.greatCircleDistance(get(counter), get(counter+1));
    }
    return sum;
  }

  public double averageSpeed(){
    double total_distance=totalDistance();
    double total_time=0.0;
    int sequence_length=size();
    for(int counter=0;counter<sequence_length-1;counter++){
      total_time+=ChronoUnit.SECONDS.between(get(counter).getTime(),get(counter+1).getTime());
    }
    return total_distance/total_time;
  }
}