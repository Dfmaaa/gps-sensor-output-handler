import java.io.IOException;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.time.temporal.ChronoUnit;
/**
 * Represents a point in space and time, recorded by a GPS sensor.
 *
 * @author Fariya Achhab
 */

//Class that deals with sequences of Point objects.
public class Track {
  
  private ArrayList<Point> objects; //sequence

  public Track(String filename) throws IOException{
    objects=new ArrayList<Point>();
    //calling method that stores Point objects in the sequence.
    readFile(filename);
  }

  //This function reads CSV files and converts the contents of it to Point objects, then it adds those Point objects to the sequence.
  public void readFile(String filename) throws IOException{
    File f=new File(filename);
    Scanner read=new Scanner(f);
    read.nextLine();
    while(read.hasNextLine()){
      String raw_line=read.nextLine();
      //Format is Time, Longitude, Latitude, Elevation.
      String[] fields=raw_line.split(",");
      if(fields.length!=4){
        read.close();
        throw new GPSException("Incorrect number of fields.");
      }
      //Converting strings to other data types so that they can be used as parameters for the constructor of the Point class.
      ZonedDateTime time=ZonedDateTime.parse(fields[0]);
      double longitude=Double.parseDouble(fields[1]);
      double latitude=Double.parseDouble(fields[2]);
      double elevation=Double.parseDouble(fields[3]);

      //Finally, adding the new Point object to the sequence.
      add(new Point(time,longitude,latitude,elevation));
    }
    read.close(); //Closing the Scanner.
   }

  //Adds an object to the sequence.
  public void add(Point p){
    objects.add(p);
  }

  //Takes an integer as parameter and returns the Point object with that index in the sequence.
  public Point get(int index){
    //Bound checking, the logic behind this is that objects with index lower than 0, and equal to or bigger than size() don't exist.
    if(index<0||index>size()-1){
      throw new GPSException("whoopsie u r wrong");
    }
    return objects.get(index);
  }
  //returns the size of the sequence.
  public int size(){
    return objects.size();
  }
  //Returns the Point object with the lowest elevation in the sequence.
  public Point lowestPoint(){
    Point lowest=get(0);
    int sequence_length=size();

    /* This algorithm takes the first element as lowestPoint,
    and then probes the array for lower Point objects.
    By the time it reaches the end of the sequence, it will have gotten the literal lowest Point.*/
    
    for(int counter=1;counter<sequence_length;counter++){
      if(lowest.getElevation()>get(counter).getElevation()){
        lowest=get(counter);
      }
    }
    return lowest;
  }

  //Returns the Point with the highest elevation in the sequence.
  public Point highestPoint(){
    Point highest=get(0);
    int sequence_length=size();
    /* This works like the lowestPoint algorithm, but it looks for higher Points instead.*/
    for(int counter=1;counter<sequence_length;counter++){
      if(highest.getElevation()<get(counter).getElevation()){
        highest=get(counter);
      }
    }
    return highest;
  }

  /* Uses greatCircleDistance of Point to compute distance between two adjacent Points.
   * It computes distance between all adjacent points in the sequence and adds all the outputs of greatCircleDistance.
   * Doing that gives us the total distance. 
  */
  public double totalDistance(){
    double sum=0.0;
    int sequence_length=size();
    for(int counter=0;counter<sequence_length-1;counter++){
      sum+=Point.greatCircleDistance(get(counter), get(counter+1));
    }
    return sum;
  }
  
  /* The literal formula for average speed is total distance divided by total time.
   * We already have a method that computes total distance so we compute the time passed between all the adjacent Points.
   * We use ChronoUnit.SECONDS.between() for that. 
   * After adding all the outputs, we use the literal formula to compute the average speed.
   */
  public double averageSpeed(){
    double total_distance=totalDistance();
    double total_time=0.0;
    int sequence_length=size();
    for(int counter=0;counter<sequence_length-1;counter++){
      total_time+=ChronoUnit.SECONDS.between(get(counter).getTime(),get(counter+1).getTime());
    }
    return total_distance/total_time;
  }
}